# Landing Page Project

going to section by click on name on navbar according to id attribute.
make the section in viewport active by adding to it the active class.
modifying the HTML and CSS files was done .
the project became an interactive one.
