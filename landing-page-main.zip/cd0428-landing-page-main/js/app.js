/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
 */

/**
 * Define Global Variables
 *
 */

var listId = document.getElementById("navbar__list");
var section = document.querySelectorAll("section");
/**
 * End Global Variables
 * Start Helper Functions
 *
 */

/**
 * End Helper Functions
 * Begin Main Functions
 *
 */

// build the nav

// Add class 'active' to section when near top of viewport

// Scroll to anchor ID using scrollTO event

/**
 * End Main Functions
 * Begin Events
 *
 */
document.addEventListener("DOMContentLoaded", addLi, false);
document.addEventListener("DOMContentLoaded", scrollingSec, false);
document.addEventListener("DOMContentLoaded", makeActive, false);
document.addEventListener("scroll", makeActive);
document.documentElement.style.scrollBehavior = "smooth"; //to make smoth scrolling among sections

// Build menu
function addLi() {
  for (let i = 0; i < section.length; i++) {
    var newLi = document.createElement("li");
    var tag = document.createElement("a");
    const secName = section[i].getAttribute("data-nav");
    const secId = section[i].getAttribute("id");
    tag.setAttribute("href", "#" + secId); //id
    tag.setAttribute("class", "menu__link"); //adding to menu class
    tag.innerText = secName; //section's name
    newLi.appendChild(tag);

    //newLi.style.paddingRight("10px");
    listId.appendChild(newLi); //adding lists to ul
  }
}

//document.querySelector('page__header')
// Scroll to section on link click
function scrollingSec() {
  event.preventDefault();
  window.scrollTo({ behavior: "smooth" });
}

// Set sections as active
var sections = document.querySelectorAll("landing__container");
function makeActive() {
  for (const section of sections) {
    const position = section.getBoundingClientRect();
    const box = position.top;
    if (
      (box >= 0 && box <= window.innerHeight) ||
      document.documentElement.clientHeight
    ) {
      //var activeClass = document.getElementsByClassName("your-active-class");
      section.classList.add("your-active-class");
    } else {
      section.classList.remove("your-active-class");
    }
  }
}
